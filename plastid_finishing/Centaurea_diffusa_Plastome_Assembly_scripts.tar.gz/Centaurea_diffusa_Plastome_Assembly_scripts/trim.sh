#!/bin/bash
prefix=$1
java -jar bin/Trimmomatic-0.30/trimmomatic-0.30.jar PE -phred33 -threads 8 rawdata/$prefix.1.fq rawdata/$prefix.2.fq cleandata/$prefix.1.fq cleandata/$prefix.orphan.1.fq cleandata/$prefix.2.fq cleandata/$prefix.orphan.2.fq ILLUMINACLIP:IlluminaContaminants.fa:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36 1>log/trim.$prefix.stdout 2>log/trim.$prefix.stderr

