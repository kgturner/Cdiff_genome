#!/bin/bash
bin/GapFiller_v1-11_linux-x86_64/GapFiller.pl \
-l gapfiller.lib \
-s gapfiller/TR001_1L.plastid.0.1.fa \
-b gapfiller.TR001_1L.plastid.0.2.fa \
-o 60 \
-d 100 \
-t 10 \
-T 8 \
1>log/gapfiller.stdout 2>log/gapfiller.stderr


#ERROR: Parameter -l is required. Please insert a library file
#ERROR: Parameter -s is required. Please insert a scaffold fastA file
#
#Usage: bin/GapFiller_v1-11_linux-x86_64/GapFiller.pl [GapFiller_v1-11_Final]
#
#============ General Parameters ============
#-l  Library file containing two paired-read files with insert size, error and orientation indication.
#-s  Fasta file containing scaffold sequences used for extension.
#============ Extension Parameters ============
#-m  Minimum number of overlapping bases with the edge of the gap (default -m 29)
#-o  Minimum number of reads needed to call a base during an extension (default -o 2)
#-r  Percentage of reads that should have a single nucleotide extension in order to close a gap in a scaffold (Default: 0.7)
#-d  Maximum difference between the gapsize and the number of gapclosed nucleotides. Extension is stopped if it matches this parameter + gap size (default -d 50, optional).
#-n  Minimum overlap required between contigs to merge adjacent sequences in a scaffold (default -n 10, optional)
#-t  Number of reads to trim off the start and begin of the sequence (usually missambled/low-coverage reads) (default -t 10, optional)
#-i  Number of iterations to fill the gaps (default -i 10, optional)
#============ Bowtie Parameters ============
#-g  Maximum number of allowed gaps during mapping with Bowtie. Corresponds to the -v option in Bowtie. (default -g 1, optional)
#============ Additional Parameters ============
#-T  Number of threads to run (default -T 1)
#-S  Skip reading of the input files again
