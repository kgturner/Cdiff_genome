#!/bin/bash

# Kathryn G. Turner & Christopher J. Grassa
# Centaurea diffusa Plastome Assembly
# Tue 29 Apr 2014 18:05:33 PDT


# trim low-quality bases and sequencing artifacts from Illumina PE
./trim.sh HI.0767.001.Index_1.TR001_1L
./trim.sh HI.0767.002.Index_1.TR001_1L


# align trimmed reads to cytoplasmic genomes of relatives and common contaminants:
#
#    contents of noncentaurea_ref.fa:
#
#    $ grep '^>' ref/noncentaurea_ref.fa
#    >gi|78675147|dbj|AP007232.1| Lactuca sativa chloroplast DNA, complete genome
#    >gi|571031384|gb|KF815390.1| Helianthus annuus mitochondrion, complete genome
#    >gi|9626372|ref|NC_001422.1| Enterobacteria phage phiX174, complete genome
#    >gi|47118301|dbj|BA000007.2| Escherichia coli O157:H7 str. Sakai DNA, complete genome
#

./prepare_ref.sh noncentaurea_ref.fa
./trimmed2bam.sh HI.0767.001.Index_1.TR001_1L noncentaurea_ref.fa
./trimmed2bam.sh HI.0767.002.Index_1.TR001_1L noncentaurea_ref.fa

# partition reads according to reference aligned to 
./partition_cytoplasm.v2.sh HI.0767.001.Index_1.TR001_1L
./partition_cytoplasm.v2.sh HI.0767.002.Index_1.TR001_1L

# concatenate two sequencing runs (they are from the same library) for the partitioned reads
partitioneddata/HI.0767.001.Index_1.TR001_1L.TO.78675147.1.fq \
partitioneddata/HI.0767.002.Index_1.TR001_1L.TO.78675147.1.fq \
>partitioneddata/cat.TR001_1L.TO.78675147.1.fq

cat \
partitioneddata/HI.0767.001.Index_1.TR001_1L.TO.78675147.2.fq \
partitioneddata/HI.0767.002.Index_1.TR001_1L.TO.78675147.2.fq \
>partitioneddata/cat.TR001_1L.TO.78675147.2.fq

# use AllPathsLG to error correct reads and join overlapping pairs
./ErrorCorrectReads.sh cat.TR001_1L.TO.78675147

# assemble error corrected reads with Ray
./ray_assemble.sh 25 cat.TR001_1L.TO.78675147

# align assembly to Lettuce reference
makeblastdb \
-in ref/Lactuca_sativa_cp_sequence.fasta \
-dbtype nucl

blastn \
-db ref/Lactuca_sativa_cp_sequence.fasta \
-query ray_out/cat.TR001_1L.TO.78675147.K.25/Contigs.fasta \
-out cat.TR001_1L.TO.78675147.K.25.Contigs._TO_.Lactuca_sativa_cp.blast7 \
-outfmt 7

# use OSLay 1.0 to super-scaffold Ray contigs according to synteny with Lettuce plastome
# OSLay is a GUI program. 
# Find chosen parameters in "oslay/OSLay.Parameters.txt"
# Find imported file names in "oslay/OSLay.ImportFiles.txt"
# Find output files in oslay/


# fill gaps in super-scaffold with GapFiller
cp oslay/supercontigSequences.x.fna gapfiller/TR001_1L.plastid.0.1.fa
./gapfiller.sh
cp gapfiller.TR001_1L.plastid.0.2.fa/gapfiller.TR001_1L.plastid.0.2.fa.gapfilled.final.fa gapfiller/TR001_1L.plastid.0.2.fa

# plotting depth of coverage (sup fig 2) of raw reads aligned (BWA) to "gapfiller/TR001_1L.plastid.0.2.fa" suggested:
# 1) a mis-assembly near supercontig1, position 12521
# 2) collapse of the inverted repeat to a single copy
#  
#  a sharp increase in depth of coverage between 83661 and 83662 indicated the IR start boundary.
#  alignment (BLASTN) of "gapfiller/TR001_1L.plastid.0.2.fa" to self indicated:
#     the misassembly was due to an erronious duplication.
#     the IR ended 127407
# The sequence was corrected in Vim based on this evidence.
# edits were verified with aTRAM assemblies of flanking regions
# 
# an iterative process of aligning reads to the reference, inspecting the alignment, and hand editing in Vim was used to fix a few small indel and substitution errors.
#
#

# 
#

