#!/bin/bash
K=$1
prefix=$2
mpirun -np 24 \
bin/Ray-v2.2.0/Ray \
-k $K \
-p ecrdata/$prefix.allpathsECR.paired.A.fastq ecrdata/$prefix.allpathsECR.paired.B.fastq \
-s ecrdata/$prefix.allpathsECR.filled.fastq \
-s ecrdata/$prefix.allpathsECR.unpaired.fastq \
-o ray_out/$prefix.K.$K \
-write-kmers \
-show-extension-choice \
-enable-neighbourhoods \
1>log/ray.$prefix.K.$K.stdout 2>log/ray.$prefix.K.$K.stderr


