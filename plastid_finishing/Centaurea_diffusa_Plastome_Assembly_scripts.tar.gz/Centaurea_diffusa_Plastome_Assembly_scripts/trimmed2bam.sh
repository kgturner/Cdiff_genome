#!/bin/bash
prefix=$1
ref_name=$2
cleandata='cleandata'
scratch='scratch'
reference="ref/$ref_name"
log='log'

bin/bwa-0.6.2/bwa aln -t 8 -q 20 $reference $cleandata/$prefix.1.fq 1>$scratch/$prefix.to.$ref_name.1.sai 2>$log/$prefix.to.$ref_name.1.aln.STDERR
bin/bwa-0.6.2/bwa aln -t 8 -q 20 $reference $cleandata/$prefix.2.fq 1>$scratch/$prefix.to.$ref_name.2.sai 2>$log/$prefix.to.$ref_name.2.aln.STDERR

bin/bwa-0.6.2/bwa sampe -P $reference $scratch/$prefix.to.$ref_name.1.sai $scratch/$prefix.to.$ref_name.2.sai $cleandata/$prefix.1.fq $cleandata/$prefix.2.fq 2>$log/$prefix.to.$ref_name.sampe.STDERR | \
bin/samtools-0.1.18/samtools view -S -u -h -t $reference.fai - 2>$log/$prefix.to.$ref_name.view.STDERR | \
bin/samtools-0.1.18/samtools sort -m 8000000000 - $scratch/$prefix.to.$ref_name.sort 2>$log/$prefix.to.$ref_name.sort.STDERR
bin/samtools-0.1.18/samtools index  $scratch/$prefix.to.$ref_name.sort.bam

bin/bwa-0.6.2/bwa aln -t 8 -q 20 $reference $cleandata/$prefix.orphan.1.fq 2>$log/$prefix.to.$ref_name.1.orphan.aln.STDERR | \
bin/bwa-0.6.2/bwa samse $reference - $cleandata/$prefix.orphan.1.fq 2>$log/$prefix.to.$ref_name.1.orphan.samse.STDERR | \
bin/samtools-0.1.18/samtools view -S -u -h -t $reference.fai - 2>$log/$prefix.to.$ref_name.1.orphan.view.STDERR | \
bin/samtools-0.1.18/samtools sort -m 8000000000 - $scratch/$prefix.to.$ref_name.orphan.1.sort 2>$log/$prefix.to.$ref_name.1.orphan.sort.STDERR 
bin/samtools-0.1.18/samtools index  $scratch/$prefix.to.$ref_name.orphan.1.sort.bam

bin/bwa-0.6.2/bwa aln -t 8 -q 20 $reference $cleandata/$prefix.orphan.2.fq 2>$log/$prefix.to.$ref_name.2.orphan.aln.STDERR | \
bin/bwa-0.6.2/bwa samse $reference - $cleandata/$prefix.orphan.2.fq 2>$log/$prefix.to.$ref_name.2.orphan.samse.STDERR | \
bin/samtools-0.1.18/samtools view -S -u -h -t $reference.fai - 2>$log/$prefix.to.$ref_name.2.orphan.view.STDERR | \
bin/samtools-0.1.18/samtools sort -m 8000000000 - $scratch/$prefix.to.$ref_name.orphan.2.sort 2>$log/$prefix.to.$ref_name.1.orphan.sort.STDERR
bin/samtools-0.1.18/samtools index  $scratch/$prefix.to.$ref_name.orphan.2.sort.bam

bin/samtools-0.1.18/samtools merge $scratch/$prefix.to.$ref_name.merge.bam $scratch/$prefix.to.$ref_name.sort.bam $scratch/$prefix.to.$ref_name.orphan.1.sort.bam $scratch/$prefix.to.$ref_name.orphan.2.sort.bam 2>$log/$prefix.to.$ref_name.merge.STDERR
bin/samtools-0.1.18/samtools index  $scratch/$prefix.to.$ref_name.merge.bam

