#!/bin/bash
prefix=$1
bin/samtools-0.1.18/samtools view -H scratch/$prefix.to.noncentaurea_ref.fa.merge.bam >partitioneddata/$prefix.noncentaurea.header.sam
cat partitioneddata/$prefix.noncentaurea.header.sam | grep '^@SQ' | cut -f 2 | cut -d \| -f 2 >noncentaurea.GIs.list

while read line
do
	cp partitioneddata/$prefix.noncentaurea.header.sam partitioneddata/$prefix.TO.$line.sam
	bin/samtools-0.1.18/samtools view scratch/$prefix.to.noncentaurea_ref.fa.merge.bam | awk -v want="$line" '$3 ~ want' |  awk 'and($2, 0x0002) && $7~"="' >> partitioneddata/$prefix.TO.$line.sam
	java -jar bin/picard-tools-1.92/SamToFastq.jar I=partitioneddata/$prefix.TO.$line.sam F=partitioneddata/$prefix.TO.$line.1.fq F2=partitioneddata/$prefix.TO.$line.2.fq
	
done<noncentaurea.GIs.list
