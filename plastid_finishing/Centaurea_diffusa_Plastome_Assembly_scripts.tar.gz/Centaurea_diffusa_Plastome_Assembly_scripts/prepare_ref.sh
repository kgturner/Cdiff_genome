#!/bin/bash
ref_name=$1
reference="ref/$ref_name"
log='log'

bin/bwa-0.6.2/bwa index $reference 1>$log/bwa.index.$ref_name.stdout 2>$log/bwa.index.$ref_name.stderr
bin/samtools-0.1.18/samtools faidx $reference 1>$log/samtools.faidx.$ref_name.stdout 2>$log/samtools.faidx.$ref_name.stderr
